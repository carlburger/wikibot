Wikibot
=========================

Testbot for Microsoft Teams.

This bot waits for chat input and searches wikipedia for a matching page. If a page is found the abstract is parsed from the page and posted back into the chat.
